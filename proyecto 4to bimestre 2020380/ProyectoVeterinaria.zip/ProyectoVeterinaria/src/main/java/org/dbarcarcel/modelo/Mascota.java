package org.dbarcarcel.modelo;
/**
 * @author David Balcárcel
 */
public class Mascota {
    private int idMascota;
    private String nombreMascota;
    private String edadMascota;
    private String duenioMascota;
    private String servicioMascota;
    private String pesoMascota;
    
    public Mascota(){}
    /**
     * Este es el metodo constructor de las variables de Mascota
     * @param idMascota Es el id de mascota
     * @param nombreMascota Es el nombre de mascota
     * @param edadMascota Es la edad de mascota
     * @param duenioMascota Es el duenio de la mascota
     * @param servicioMascota Es el nombre del servicio que recivira la mascota
     * @param pesoMascota Es el preso de la mascota
     */

    public Mascota(int idMascota, String nombreMascota, String edadMascota, String duenioMascota, String servicioMascota, String pesoMascota) {
        this.idMascota = idMascota;
        this.nombreMascota = nombreMascota;
        this.edadMascota = edadMascota;
        this.duenioMascota = duenioMascota;
        this.servicioMascota = servicioMascota;
        this.pesoMascota = pesoMascota;
    }

    /**
     * Getter del id de mascota
     * @return retorna el id de mascota
     */
    public int getIdMascota() {
        return idMascota;
    }

    /**
     * Setter del id de mascota
     * @param idMascota id de mascota
     */
    public void setIdMascota(int idMascota) {
        this.idMascota = idMascota;
    }

    /**
     * Getter del nombre de la mascota
     * @return retorna el nombre de la mascota
     */
    public String getNombreMascota() {
        return nombreMascota;
    }

    /**
     * Setter del nombre de la mascota
     * @param nombreMascota nombre de la mascota
     */
    public void setNombreMascota(String nombreMascota) {
        this.nombreMascota = nombreMascota;
    }

    /**
     * Getter de la edad de la mascota
     * @return retorna la edad de la mascota
     */
    public String getEdadMascota() {
        return edadMascota;
    }

    /**
     * Setter de la edad de la mascota
     * @param edadMascota edad de la mascota
     */
    public void setEdadMascota(String edadMascota) {
        this.edadMascota = edadMascota;
    }

    /**
     * Getter de el nombre del duenio de la mascota
     * @return retorna el nombre del duenio de la mascota
     */
    public String getDuenioMascota() {
        return duenioMascota;
    }

    /**
     * Setter del nombre del duenio de la mascota
     * @param duenioMascota nombre del duenio de la mascota
     */
    public void setDuenioMascota(String duenioMascota) {
        this.duenioMascota = duenioMascota;
    }

    /**
     * Getter del nombre del servicio que recibira la mascota
     * @return retorna el nombre del servicio que recibira la mascota
     */
    public String getServicioMascota() {
        return servicioMascota;
    }

    /**
     * Setter del nombre del servicio que recibira la mascota
     * @param servicioMascota nombre del servicio que recibira la mascota
     */
    public void setServicioMascota(String servicioMascota) {
        this.servicioMascota = servicioMascota;
    }

    /**
     * Getter del peso de la mascota
     * @return retorna el peso de la mascota
     */
    public String getPesoMascota() {
        return pesoMascota;
    }

    /**
     * Setter del peso de la mascota
     * @param pesoMascota peso de la mascota
     */
    public void setPesoMascota(String pesoMascota) {
        this.pesoMascota = pesoMascota;
    }
    
    
    

}
