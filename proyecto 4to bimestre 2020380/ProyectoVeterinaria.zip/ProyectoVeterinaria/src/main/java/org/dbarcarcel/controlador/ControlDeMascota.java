package org.dbarcarcel.controlador;
import java.util.ArrayList;
import org.dbarcarcel.modelo.Mascota;
/**
 * @author David Balcárcel 
 */
public class ControlDeMascota {
    private static ControlDeMascota instanciaUnica;
	private ArrayList<Mascota> listaDeMascota;

	
	private ControlDeMascota(){//Constructor
		listaDeMascota = new ArrayList<Mascota>();
	}

	/**
	 * Con este metodo se controlan las mascotas
	 * @return retorna instanciaUnica
	 */
	public static ControlDeMascota getInstancia(){
		if(instanciaUnica == null){
			instanciaUnica = new ControlDeMascota();
		}return instanciaUnica;
	}

	/**
	 * Agrega una mascota
	 * @param nuevoMascota mascota que se agragara
	 */
	public void agregarMascota(Mascota nuevoMascota){
		listaDeMascota.add(nuevoMascota);
	}

	/**
	 * Muestra una lista de las mascotas guardadas
	 * @return retorna una lista de mascotas
	 */
	public ArrayList<Mascota> mostrarMascota(){
		return listaDeMascota;
	}

	/**
	 * Muestra una mascota en especifico
	 * @param id Id de la mascota a mostrar
	 * @return retorna la mascota encontrada
	 */
	public Mascota verMascota(int id){
		Mascota mascotaEncontrado = new Mascota();
		for(Mascota mascota : listaDeMascota){
			if(mascota.getIdMascota() == id){
				mascotaEncontrado = mascota;
				break;
			}
		}
		return mascotaEncontrado;
	}

	/**
	 * Elimina una mascota
	 * @param mascotaAEliminar Mascota que se eliminara
	 */
	public void borrarMascota(Mascota mascotaAEliminar){
		listaDeMascota.remove(mascotaAEliminar);
	}

	/**
	 * Eliminara una mascota usando su id
	 * @param id Id de la mascota que se eliminara
	 */
	public void borrarMascota(int id){
		Mascota mascotaAEliminar = new Mascota();
		for(Mascota mascota : listaDeMascota){
			if(mascota.getIdMascota() == id){
				mascotaAEliminar = mascota;
				listaDeMascota.remove(mascotaAEliminar);
				break;
			}
		}
	}	

	/**
	 * Actualiza un pais
	 * @param mascotaAntiguo mascota a actualizar
	 * @param mascotaActualizado mascota actualizada
	 */
	public void actualizarMascota(Mascota mascotaAntiguo, Mascota mascotaActualizado){
		int indiceDelArray = listaDeMascota.indexOf(mascotaAntiguo);
		listaDeMascota.set(indiceDelArray, mascotaActualizado);
	}

	/**
	 * Muestra la cantidad de paises almacenados
	 * @return retorna la cantidad de paises almacenados
	 */
	public int cantidadDeMascotas(){
		return listaDeMascota.size ();
	}
}
