package org.dbarcarcel.modelo;
/**
 * @author Davod Balcárcel
 */
public class Medico {
    //Fase de declaracion de variables de instancia
    private int idMedico;
    private String nombreMedico;
    private String apellidoMedico;
    private int telefonoMedico;
    private String especialidadMedico;
    private String emailMedico;
    private int colegiadoMedico;
    //Fase de declaracion y definicion de metodos
    public Medico() {} //Constructor nulo, solo crea una instancia vacia
    /**
     * Este es el metodo constructor de las variables de medico
     * @param idMedico Es el id del medico
     * @param nombreMedico Es el nombre del medico
     * @param apellidoMedico Es el apellido del medico
     * @param telefonoMedico Es el telefono del medico
     * @param especialidadMedico Es la especialidad del medico
     * @param emailMedico Es el email del medico
     * @param colegiadoMedico Es el colegiado del medico
     */

    public Medico(int idMedico, String nombreMedico, String apellidoMedico, int telefonoMedico, String especialidadMedico, String emailMedico, int colegiadoMedico) {
        this.idMedico = idMedico;
        this.nombreMedico = nombreMedico;
        this.apellidoMedico = apellidoMedico;
        this.telefonoMedico = telefonoMedico;
        this.especialidadMedico = especialidadMedico;
        this.emailMedico = emailMedico;
        this.colegiadoMedico = colegiadoMedico;
    }

    /**
     * Getter del id del medico
     * @return retorna el id del medico
     */
    public int getIdMedico() {
        return idMedico;
    }
    /**
     * Setter del id del medico
     * @param idMedico id del medico
     */
    public void setIdMedico(int idMedico) {
        this.idMedico = idMedico;
    }
    
    /**
     * Getter del nombre del medico
     * @return retorna el nombre del medico
     */
    public String getNombreMedico() {
        return nombreMedico;
    }
    
    /**
     * Setter del nombre del medico
     * @param nombreMedico nombre del medico
     */
    public void setNombreMedico(String nombreMedico) {
        this.nombreMedico = nombreMedico;
    }

    /**
     * Getter del apellido del medico
     * @return retorna el apellido del medico
     */
    public String getApellidoMedico() {
        return apellidoMedico;
    }

    /**
     * Setter del apellido del medico
     * @param apellidoMedico apellido del medico
     */
    public void setApellidoMedico(String apellidoMedico) {
        this.apellidoMedico = apellidoMedico;
    }

    /**
     * Getter del telefono del medico
     * @return retorna el telefono del medico
     */
    public int getTelefonoMedico() {
        return telefonoMedico;
    }

    /**
     * Setter del telefono del medico
     * @param telefonoMedico telefono del medico
     */
    public void setTelefonoMedico(int telefonoMedico) {
        this.telefonoMedico = telefonoMedico;
    }

    /**
     * Getter del la especialidad del medico
     * @return retorna la especialidad del medico
     */
    public String getEspecialidadMedico() {
        return especialidadMedico;
    }

    /**
     * Setter de la especialidad del medico
     * @param especialidadMedico especialidad medico
     */
    public void setEspecialidadMedico(String especialidadMedico) {
        this.especialidadMedico = especialidadMedico;
    }

    /**
     * Getter del email del medico
     * @return retorna el email del medico
     */
    public String getEmailMedico() {
        return emailMedico;
    }

    /**
     * Setter del email del medico
     * @param emailMedico email del medico
     */
    public void setEmailMedico(String emailMedico) {
        this.emailMedico = emailMedico;
    }

    /**
     * Getter del colegiado del medico
     * @return retorna el colegiado del medico
     */
    public int getColegiadoMedico() {
        return colegiadoMedico;
    }

    /**
     * Setter del colegiado del medico
     * @param colegiadoMedico colegiado del medico
     */
    public void setColegiadoMedico(int colegiadoMedico) {
        this.colegiadoMedico = colegiadoMedico;
    }
    
}