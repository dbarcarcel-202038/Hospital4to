package org.dbarcarcel.controlador;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import org.dbarcarcel.modelo.Servicio;
import javax.swing.table.DefaultTableModel;
import org.dbarcarcel.db.Conexion;
import org.dbarcarcel.modelo.Cliente;
/**
 * @author David Balcárcel
 */
public class ControlDeServicio {
    private static ArrayList<Servicio> servicios;
    private static ControlDeServicio instancia = null;    
    
   public ControlDeServicio(){
        servicios = new ArrayList<Servicio>();
        enlistaServicios();
   }
   
        
   public static ControlDeServicio getInstancia(){
       if(instancia == null){
           instancia = new ControlDeServicio();
       }
       return instancia;
   }
   public void agregarServicio(Servicio servicio){
        try{
            PreparedStatement sentencia = Conexion.getInstancia().getConexion().prepareCall("call sp_agregarServicio(?,?,?,?);");
            sentencia.setString(1,servicio.getNombreServicio());
            sentencia.setString(2,servicio.getPrecioServicio());
            sentencia.setString(3,servicio.getTiempoServicio());
            sentencia.setString(4,servicio.getEncargadoServicio());
            
            sentencia.execute();
            servicios.add(servicio);
            JOptionPane.showMessageDialog(null, "Ha enviado un servicio a la BD.");
        }catch(Exception error){
            error.printStackTrace();
        }
    }
   
   public void actualizarServicio(Servicio servicio){
        try{
            int posicionEnArray = servicios.indexOf(servicio);
            PreparedStatement sentencia = Conexion.getInstancia().getConexion().prepareCall("call sp_actualizarServicio(?,?,?,?,?);");
            sentencia.setInt(1,servicio.getIdServicio());
            sentencia.setString(2,servicio.getNombreServicio());
            sentencia.setString(3,servicio.getPrecioServicio());
            sentencia.setString(4,servicio.getTiempoServicio());
            sentencia.setString(5,servicio.getEncargadoServicio());   
            sentencia.execute();
            servicios.set(posicionEnArray,servicio);
            JOptionPane.showMessageDialog(null,"Ha actualizado un servicio de la BD.");
        }catch(Exception error){
            error.printStackTrace();
        }   
    }
        
    public void enlistaServicios(){        
        try{
        PreparedStatement sentencia = Conexion.getInstancia().getConexion().prepareCall("call sp_enlistaServicios()");
        ResultSet resultado = sentencia.executeQuery();
        while(resultado.next()){
            Servicio servicio = new Servicio();
            servicio.setIdServicio(resultado.getInt(1));
            servicio.setNombreServicio(resultado.getNString(2));
            servicio.setPrecioServicio(resultado.getNString(3));
            servicio.setTiempoServicio(resultado.getNString(4));
            servicio.setEncargadoServicio(resultado.getNString(5));
            servicios.add(servicio);
            
            servicios.add(servicio);
        }
        }catch(Exception error){
            error.printStackTrace();
        } 
        
        
    }
    public ArrayList<Servicio> listaDeServicios(){
        return servicios;
    }
    public int cantidadDeServicios(){
        return servicios.size();
    }
}
