package org.dbarcarcel.modelo;
/**
 * @author David Balcárcel
 */
public class Cliente {
    //Fase de declaracion de variables de instancia
    private int idCliente;
    private String nombreCliente;
    private String apellidoCliente;
    private String telefonoCliente;
    private String mascotaCliente;
    private String servicioCliente;
    private String visitaCliente;
    //Fase de declaracion y deficnicion de metodos
    public Cliente(){}
    /**
     * Este es el metodo constructor de las variables de cliente
     * @param idCliente Es el id del cliente
     * @param nombreCliente Es el nombre del cliente
     * @param apellidoCliente Es el apellido del cliente
     * @param telefonoCliente Es el telefono del cliente
     * @param mascotaCliente Es el nombre de la mascota del cliente
     * @param servicioCliente Es el nombre del servicio que recibira la mascota
     * @param visitaCliente Es la fecha de visita del cliente
     */
    public Cliente(int idCliente, String nombreCliente, String apellidoCliente, String telefonoCliente, String mascotaCliente, String servicioCliente, String visitaCliente) {
        this.idCliente = idCliente;
        this.nombreCliente = nombreCliente;
        this.apellidoCliente = apellidoCliente;
        this.telefonoCliente = telefonoCliente;
        this.mascotaCliente = mascotaCliente;
        this.servicioCliente = servicioCliente;
        this.visitaCliente = visitaCliente;
    }

    /**
     * Getter del id del cliente
     * @return retorna el id del cliente
     */
    public int getIdCliente() {
        return idCliente;
    }
    /**
     * Setter del id del cliente
     * @param idCliente id del cliente
     */
    public void setIdCliente(int idCliente) {
        this.idCliente = idCliente;
    }

    /**
     * Getter del nombre del cliente
     * @return retorna el nombre del cliente
     */
    public String getNombreCliente() {
        return nombreCliente;
    }
    /**
     * Setter del nombre del cliente
     * @param nombreCliente nombre del cliente
     */
    public void setNombreCliente(String nombreCliente) {
        this.nombreCliente = nombreCliente;
    }
    /**
     * Getter del apellido del cliente
     * @return retorna el apellido del cliente
     */
    public String getApellidoCliente() {
        return apellidoCliente;
    }
    /**
     * Setter del apellido del cliente
     * @param apellidoCliente apellido del cliente
     */
    public void setApellidoCliente(String apellidoCliente) {
        this.apellidoCliente = apellidoCliente;
    }
    /**
     * Getter del telefono del cliente
     * @return retorna el telefono del cliente
     */
    public String getTelefonoCliente() {
        return telefonoCliente;
    }
    /**
     * Setter del telefono del cliente
     * @param telefonoCliente telefono del cliente
     */
    public void setTelefonoCliente(String telefonoCliente) {
        this.telefonoCliente = telefonoCliente;
    }
    /**
     * Getter del nombre de la mascota del cliente
     * @return retorna el nombre de la mascota del cliente
     */
    public String getMascotaCliente() {
        return mascotaCliente;
    }
    /**
     * Setter del nombre de la mascota del cliente
     * @param mascotaCliente nombre de la mascota del cliente
     */
    public void setMascotaCliente(String mascotaCliente) {
        this.mascotaCliente = mascotaCliente;
    }
    /**
     * Getter del nombre servicio que se dara a la mascota del cliente
     * @return retorna el nombre servicio que se dara a la mascota del cliente
     */
    public String getServicioCliente() {
        return servicioCliente;
    }
    /**
     * Setter del nombre servicio que se dara a la mascota del cliente
     * @param servicioCliente nombre servicio que se dara a la mascota del cliente
     */
    public void setServicioCliente(String servicioCliente) {
        this.servicioCliente = servicioCliente;
    }
    /**
     * Getter de la fecha de visita del cliente
     * @return retorna la fecha de visita del cliente
     */
    public String getVisitaCliente() {
        return visitaCliente;
    }
    /**
     * Setter de la fecha de visita del cliente
     * @param visitaCliente fecha de visita del cliente
     */
    public void setVisitaCliente(String visitaCliente) {
        this.visitaCliente = visitaCliente;
    }
    
    /*@Override
    public String toString() {
        return "Cliente{" + "idCliente=" + idCliente + ", nombreCliente=" + nombreCliente + ", apellidoCliente=" + apellidoCliente + ", telefonoCliente=" + telefonoCliente + ", mascotaCliente=" + mascotaCliente + ", servicioCliente=" + servicioCliente + ", visitaCliente=" + visitaCliente + '}';
    }*/
    
}
