package org.dbarcarcel.controlador;
import java.util.ArrayList;
import org.dbarcarcel.modelo.Medico;
/**
 * @author David Balcárcel 
 */
public class ControlDeMedico {
    private static ControlDeMedico instanciaUnica;
	private ArrayList<Medico> listaDeMedico;


	private ControlDeMedico(){//Constructor
		listaDeMedico = new ArrayList<Medico>();
	}

	/**
	 * Con este metodo se controlan los medicos
	 * @return retorna instancia unica
	 */
	public static ControlDeMedico getInstancia(){
		if(instanciaUnica == null){
			instanciaUnica = new ControlDeMedico();
		}return instanciaUnica;
	}

	/**
	 * Agrega un medico
	 * @param nuevoMedico medico que se agregara
	 */
	public void agregarMedico(Medico nuevoMedico){
		listaDeMedico.add(nuevoMedico);
	}

	/**
	 * Muestra la lista de medicos guardados
	 * @return retorna la lista de medicos
	 */
	public ArrayList<Medico> mostrarMedico(){
		return listaDeMedico;
	}

	/**
	 * Muestra un servicio en especifico
	 * @param id Id del medico a encontrar
	 * @return retorna el medico encontrado
	 */
	public Medico verMedico(int id){
		Medico medicoEncontrado = new Medico();
		for(Medico medico : listaDeMedico){
			if(medico.getIdMedico() == id){
				medicoEncontrado = medico;
				break;
			}
		}
		return medicoEncontrado;
	}

	/**
	 * Elimina un medico
	 * @param medicoAEliminar medico a eliminar
	 */
	public void borrarMedico(Medico medicoAEliminar){
		listaDeMedico.remove(medicoAEliminar);
	}

	/**
	 * Elimina un medico usando su id
	 * @param id Id del medico a eliminar
	 */
	public void borrarMedico(int id){
		Medico medicoAEliminar = new Medico();
		for(Medico medico : listaDeMedico){
			if(medico.getIdMedico() == id){
				medicoAEliminar = medico;
				listaDeMedico.remove(medicoAEliminar);
				break;
			}
		}
	}	

	/**
	 * Actualiza un medico
	 * @param medicoAntiguo medico a actualizar
	 * @param medicoActualizado medico actualizado
	 */
	public void actualizarMedico(Medico medicoAntiguo, Medico medicoActualizado){
		int indiceDelArray = listaDeMedico.indexOf(medicoAntiguo);
		listaDeMedico.set(indiceDelArray, medicoActualizado);
	}

	/**
	 * Muestra la cantidad de medicos almacenados
	 * @return retorna la cantidad de medicos almacenados 
	 */
	public int cantidadDeMedicos(){
		return listaDeMedico.size ();
	}
    
}