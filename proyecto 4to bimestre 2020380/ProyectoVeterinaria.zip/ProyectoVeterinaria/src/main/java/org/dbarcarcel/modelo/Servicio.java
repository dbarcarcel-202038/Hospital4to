package org.dbarcarcel.modelo;
/**
 * @author David Balcárcel
 */
public class Servicio {
    private int IdServicio;
    private String nombreServicio;
    private String precioServicio;
    private String tiempoServicio;
    private String encargadoServicio;
    
    public Servicio(){}
    /**
     * Este es el metodo constructor de las variables de Servicio
     * @param IdServicio Es el id del servicio
     * @param nombreServicio Es el nombre del servicio
     * @param precioServicio Es el precio del servicio
     * @param tiempoServicio Es el tiempo que se llevara en realizar el servicio
     * @param encargadoServicio Es el nombre del encargado del servicio
     */

    public Servicio(int IdServicio, String nombreServicio, String precioServicio, String tiempoServicio, String encargadoServicio) {
        this.IdServicio = IdServicio;
        this.nombreServicio = nombreServicio;
        this.precioServicio = precioServicio;
        this.tiempoServicio = tiempoServicio;
        this.encargadoServicio = encargadoServicio;
    }

    /**
     * Getter del id del servicio
     * @return retorna el id del servicio
     */
    public int getIdServicio() {
        return IdServicio;
    }

    /**
     * Setter de id del servicio
     * @param IdServicio id del servicio
     */
    public void setIdServicio(int IdServicio) {
        this.IdServicio = IdServicio;
    }

    /**
     * Setter de nombre del servicio
     * @return retorna el nombre del servicio
     */
    public String getNombreServicio() {
        return nombreServicio;
    }

    /**
     * Setter del nombre del servicio
     * @param nombreServicio nombre del servicio
     */
    public void setNombreServicio(String nombreServicio) {
        this.nombreServicio = nombreServicio;
    }

    /**
     * Getter del precio del servicio
     * @return retorna el precio del servicio
     */
    public String getPrecioServicio() {
        return precioServicio;
    }

    /**
     * Setter del precio del servicio
     * @param precioServicio precio del servicio
     */
    public void setPrecioServicio(String precioServicio) {
        this.precioServicio = precioServicio;
    }

    /**
     * Getter de tiempo del servicio
     * @return retorna el tiempo del servicio
     */
    public String getTiempoServicio() {
        return tiempoServicio;
    }

    /**
     * Setter del tiempo del servicio
     * @param tiempoServicio tiempo del servicio
     */
    public void setTiempoServicio(String tiempoServicio) {
        this.tiempoServicio = tiempoServicio;
    }

    /**
     * Getter del encargado del servicio
     * @return retorna el nombre del encargado del servicio
     */
    public String getEncargadoServicio() {
        return encargadoServicio;
    }

    /**
     * Setter del encargado del servicio
     * @param encargadoServicio encargado del servicio
     */
    public void setEncargadoServicio(String encargadoServicio) {
        this.encargadoServicio = encargadoServicio;
    }
 
    @Override
    public String toString(){
    return "Servicio{" + "idServicio=" + IdServicio + ", nombreServicio=" + nombreServicio + ", precioServicio=" + precioServicio + ", tiempoServicio=" + tiempoServicio + ", encargadoServicio=" + encargadoServicio + '}';
}    
}
