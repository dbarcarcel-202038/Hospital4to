package org.dbarcarcel.controlador;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import org.dbarcarcel.modelo.Cliente;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import org.dbarcarcel.db.Conexion;
/**
 * @author David Balcárcel
 */
public class ControlDeCliente {
    private static ArrayList<Cliente> clientes;
    private static ControlDeCliente instancia = null;    
    
   public ControlDeCliente(){
        clientes = new ArrayList<Cliente>();
        enlistaClientes();
    }
    public static ControlDeCliente getInstancia(){
        if(instancia == null){
            instancia = new ControlDeCliente();
        }
        return instancia;
    }
    public void agregarCliente(Cliente cliente){
        try{
            PreparedStatement sentencia = Conexion.getInstancia().getConexion().prepareCall("call sp_agregarCliente(?,?,?,?,?,?);");
            sentencia.setString(1,cliente.getNombreCliente());
            sentencia.setString(2,cliente.getApellidoCliente());
            sentencia.setString(3,cliente.getTelefonoCliente());
            sentencia.setString(4,cliente.getMascotaCliente());
            sentencia.setString(5,cliente.getServicioCliente());
            sentencia.setString(6,cliente.getVisitaCliente());
            sentencia.execute();
            clientes.add(cliente);
            JOptionPane.showMessageDialog(null, "Ha enviado un cliente a la BD.");
        }catch(Exception error){
            error.printStackTrace();
        }
    }
    
        public void enlistaClientes(){        
        try{
        PreparedStatement sentencia = Conexion.getInstancia().getConexion().prepareCall("call sp_enlistaClientes()");
        ResultSet resultado = sentencia.executeQuery();
        while(resultado.next()){
            Cliente cliente = new Cliente();
            cliente.setIdCliente(resultado.getInt(1));
            cliente.setNombreCliente(resultado.getNString(2));
            cliente.setApellidoCliente(resultado.getNString(3));                
            cliente.setTelefonoCliente(resultado.getString(4));  
            cliente.setMascotaCliente(resultado.getNString(5));
            cliente.setServicioCliente(resultado.getNString(6));
            cliente.setVisitaCliente(resultado.getNString(7));
            clientes.add(cliente);
        }
        }catch(Exception error){
            error.printStackTrace();
        }        
    }
            
    public void actualizarCliente(Cliente cliente){
        try{
            //int posicionEnArray = clientes.indexOf(cliente);
            PreparedStatement sentencia = Conexion.getInstancia().getConexion().prepareCall("call sp_actualizarCliente(?,?,?,?,?,?,?);");
            sentencia.setInt(1,cliente.getIdCliente());
            sentencia.setString(2,cliente.getNombreCliente());
            sentencia.setString(3,cliente.getApellidoCliente());
            sentencia.setString(4,cliente.getTelefonoCliente());
            sentencia.setString(5,cliente.getMascotaCliente());
            sentencia.setString(6,cliente.getServicioCliente());
            sentencia.setString(7,cliente.getVisitaCliente());
            sentencia.execute();
            //clientes.set(posicionEnArray,cliente);
            JOptionPane.showMessageDialog(null,"Ha actualizado un cliente de la BD.");
        }catch(Exception error){
            error.printStackTrace();
        }   
    }
    
    public void eliminarCliente(Cliente cliente){
        try{
            PreparedStatement sentencia = Conexion.getInstancia().getConexion().prepareCall("call sp_eliminarCliente(?);");
            sentencia.setInt(1,cliente.getIdCliente());
            /*sentencia.setString(2,cliente.getNombreCliente());
            sentencia.setString(3,cliente.getApellidoCliente());
            sentencia.setString(4,cliente.getTelefonoCliente());
            sentencia.setString(5,cliente.getMascotaCliente());
            sentencia.setString(6,cliente.getServicioCliente());
            sentencia.setString(7,cliente.getVisitaCliente());*/
            sentencia.execute();
            JOptionPane.showMessageDialog(null,"Ha eliminado un cliente de la BD.");
        }catch (Exception error){
            error.printStackTrace();
        }
    }
    
    public int cantidadDeClientes(){
        return clientes.size();
    }
    public ArrayList<Cliente> listaDeLibros(){
        return clientes;
    }
}